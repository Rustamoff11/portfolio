import React from 'react'

function Education() {
  return (
    <div>Najot Ta'lim</div>
  )
}

export default Education